@extends('admin.layouts.app')

@section('title', 'Settings - COAVerify™')
@section('page_title', 'Website Settings')
@section('page_subtitle', 'Manage website branding, homepage hero section, and homepage images.')
@php
    $siteSetting = $siteSetting ?? $setting ?? \App\Models\SiteSetting::current();
@endphp
@section('content')

<div class="panel">
    <form method="POST" action="{{ route('admin.settings.update') }}" enctype="multipart/form-data">
        @csrf

        <h2 style="margin:0 0 18px;color:#f7dc95;font-family:Georgia,'Times New Roman',serif;">
            Brand Settings
        </h2>

        <div class="form-grid">
            <div class="form-group">
                <label>Site Name</label>
                <input type="text" name="site_name" value="{{ old('site_name', $siteSetting->site_name) }}" placeholder="COAVerify™">
            </div>

            <div class="form-group">
                <label>Site Tagline</label>
                <input type="text" name="site_tagline" value="{{ old('site_tagline', $siteSetting->site_tagline) }}" placeholder="Batch Purity Verification">
            </div>

            <div class="form-group">
                <label>Logo</label>

                @if($siteSetting->site_logo)
                    <div style="margin-bottom:10px;">
                        <img
                            src="{{ asset('storage/' . $siteSetting->site_logo) }}"
                            alt="Logo"
                            style="max-width:180px;max-height:100px;border:1px solid rgba(215,181,109,.32);border-radius:14px;padding:8px;background:#000;"
                        >
                    </div>
                @endif

                <input type="file" name="site_logo" accept=".jpg,.jpeg,.png,.webp">
            </div>

            <div class="form-group">
                <label>Favicon</label>

                @if($siteSetting->favicon)
                    <div style="margin-bottom:10px;">
                        <img
                            src="{{ asset('storage/' . $siteSetting->favicon) }}"
                            alt="Favicon"
                            style="max-width:70px;max-height:70px;border:1px solid rgba(215,181,109,.32);border-radius:12px;padding:6px;background:#000;"
                        >
                    </div>
                @endif

                <input type="file" name="favicon" accept=".jpg,.jpeg,.png,.webp,.ico">
            </div>

            <div class="form-group full">
                <label>Footer Disclaimer</label>
                <textarea name="footer_disclaimer" rows="3">{{ old('footer_disclaimer', $siteSetting->footer_disclaimer) }}</textarea>
            </div>
        </div>

        <hr style="border:0;border-top:1px solid rgba(215,181,109,.22);margin:28px 0;">

        <h2 style="margin:0 0 18px;color:#f7dc95;font-family:Georgia,'Times New Roman',serif;">
            Homepage Hero Section
        </h2>

        <div class="form-grid">
            <div class="form-group">
                <label>Hero Badge</label>
                <input
                    type="text"
                    name="home_hero_badge"
                    value="{{ old('home_hero_badge', $siteSetting->home_hero_badge) }}"
                    placeholder="Third-Party Batch Verification"
                >
            </div>

            <div class="form-group">
                <label>Hero Highlight Word</label>
                <input
                    type="text"
                    name="home_hero_highlight"
                    value="{{ old('home_hero_highlight', $siteSetting->home_hero_highlight) }}"
                    placeholder="You Can Trust"
                >
            </div>

            <div class="form-group full">
                <label>Hero Main Title</label>
                <input
                    type="text"
                    name="home_hero_title"
                    value="{{ old('home_hero_title', $siteSetting->home_hero_title) }}"
                    placeholder="Independent COA Verification"
                >
            </div>

            <div class="form-group full">
                <label>Hero Description</label>
                <textarea name="home_hero_description" rows="4" placeholder="Write homepage hero description...">{{ old('home_hero_description', $siteSetting->home_hero_description) }}</textarea>
            </div>

            <div class="form-group">
                <label>Primary Button Text</label>
                <input
                    type="text"
                    name="home_primary_button_text"
                    value="{{ old('home_primary_button_text', $siteSetting->home_primary_button_text) }}"
                    placeholder="Verify a Batch"
                >
            </div>

            <div class="form-group">
                <label>Secondary Button Text</label>
                <input
                    type="text"
                    name="home_secondary_button_text"
                    value="{{ old('home_secondary_button_text', $siteSetting->home_secondary_button_text) }}"
                    placeholder="Test Your Sample"
                >
            </div>

            <div class="form-group">
                <label>Third Button Text</label>
                <input
                    type="text"
                    name="home_third_button_text"
                    value="{{ old('home_third_button_text', $siteSetting->home_third_button_text) }}"
                    placeholder="Submit Sample"
                >
            </div>

            <div class="form-group full">
                <label>Hero Report Image</label>

                @if($siteSetting->home_hero_image)
                    <div style="margin-bottom:12px;">
                        <img
                            src="{{ asset('storage/' . $siteSetting->home_hero_image) }}"
                            alt="Hero Image"
                            style="max-width:360px;max-height:220px;border:1px solid rgba(215,181,109,.32);border-radius:18px;padding:8px;background:#000;object-fit:contain;"
                        >
                    </div>
                @endif

                <input type="file" name="home_hero_image" accept=".jpg,.jpeg,.png,.webp">
                <span class="help">Recommended: hero-report.png style image, 1200x900 or similar.</span>
            </div>
        </div>

        <hr style="border:0;border-top:1px solid rgba(215,181,109,.22);margin:28px 0;">

        <h2 style="margin:0 0 18px;color:#f7dc95;font-family:Georgia,'Times New Roman',serif;">
            Homepage Images & Sections
        </h2>

        <div class="form-grid">
            <div class="form-group">
                <label>How It Works Title</label>
                <input
                    type="text"
                    name="home_how_title"
                    value="{{ old('home_how_title', $siteSetting->home_how_title) }}"
                    placeholder="How COAVerify™ Works"
                >
            </div>

            <div class="form-group">
                <label>Lab Section Title</label>
                <input
                    type="text"
                    name="home_lab_title"
                    value="{{ old('home_lab_title', $siteSetting->home_lab_title) }}"
                    placeholder="Built for Laboratory-Level Confidence"
                >
            </div>

            <div class="form-group full">
                <label>How It Works Description</label>
                <textarea name="home_how_description" rows="3">{{ old('home_how_description', $siteSetting->home_how_description) }}</textarea>
            </div>

            <div class="form-group full">
                <label>Lab Section Description</label>
                <textarea name="home_lab_description" rows="3">{{ old('home_lab_description', $siteSetting->home_lab_description) }}</textarea>
            </div>

            <div class="form-group">
                <label>How It Works Image</label>

                @if($siteSetting->home_how_image)
                    <div style="margin-bottom:12px;">
                        <img
                            src="{{ asset('storage/' . $siteSetting->home_how_image) }}"
                            alt="How It Works"
                            style="max-width:260px;max-height:160px;border:1px solid rgba(215,181,109,.32);border-radius:18px;padding:8px;background:#000;object-fit:contain;"
                        >
                    </div>
                @endif

                <input type="file" name="home_how_image" accept=".jpg,.jpeg,.png,.webp">
            </div>

            <div class="form-group">
                <label>Lab / Medicine Testing Image</label>

                @if($siteSetting->home_lab_image)
                    <div style="margin-bottom:12px;">
                        <img
                            src="{{ asset('storage/' . $siteSetting->home_lab_image) }}"
                            alt="Lab Testing"
                            style="max-width:260px;max-height:160px;border:1px solid rgba(215,181,109,.32);border-radius:18px;padding:8px;background:#000;object-fit:contain;"
                        >
                    </div>
                @endif

                <input type="file" name="home_lab_image" accept=".jpg,.jpeg,.png,.webp">
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Save Settings</button>
        </div>
    </form>
</div>

@endsection