<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\SampleSubmission;
use Illuminate\Http\Request;

class SampleSubmissionController extends Controller
{
    public function create()
    {
        return view('frontend.submit-sample');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'company_name' => ['required', 'string', 'max:255'],
            'contact_name' => ['nullable', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:30'],

            'product_name' => ['required', 'string', 'max:255'],
            'batch_number' => ['nullable', 'string', 'max:100'],
            'strength' => ['nullable', 'string', 'max:100'],

            'notes' => ['nullable', 'string', 'max:3000'],

            'sample_label_image' => [
                'nullable',
                'file',
                'mimes:jpg,jpeg,png,webp',
                'max:10240'
            ],

            'coa_file' => [
                'nullable',
                'file',
                'mimes:pdf,jpg,jpeg,png,webp',
                'max:10240'
            ],
        ]);

        $sampleLabelPath = null;
        $coaFilePath = null;

        if ($request->hasFile('sample_label_image')) {
            $sampleLabelPath = $request
                ->file('sample_label_image')
                ->store('sample-submissions/labels', 'public');
        }

        if ($request->hasFile('coa_file')) {
            $coaFilePath = $request
                ->file('coa_file')
                ->store('sample-submissions/coa-files', 'public');
        }

        SampleSubmission::create([
            'company_name' => $validated['company_name'],
            'contact_name' => $validated['contact_name'] ?? null,
            'email' => $validated['email'],
            'phone' => $validated['phone'] ?? null,

            'product_name' => $validated['product_name'],
            'batch_number' => $validated['batch_number'] ?? null,
            'strength' => $validated['strength'] ?? null,

            'notes' => $validated['notes'] ?? null,

            'sample_label_image' => $sampleLabelPath,
            'coa_file' => $coaFilePath,

            'status' => 'new',
        ]);

        return redirect()
            ->route('sample.submit')
            ->with('success', 'Your sample details have been submitted successfully. Our verification team will review the information and contact you if required.');
    }
}