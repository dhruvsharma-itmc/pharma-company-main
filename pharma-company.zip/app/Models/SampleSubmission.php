<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SampleSubmission extends Model
{
    protected $fillable = [
        'company_name',
        'contact_name',
        'email',
        'phone',
        'product_name',
        'batch_number',
        'strength',
        'notes',
        'sample_label_image',
        'coa_file',
        'status',
    ];

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'new' => 'New',
            'under_review' => 'Under Review',
            'verified' => 'Verified',
            'rejected' => 'Rejected',
            default => ucfirst(str_replace('_', ' ', $this->status)),
        };
    }
}