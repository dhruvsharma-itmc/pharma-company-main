<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SiteSetting extends Model
{
    protected $fillable = [
        'site_name',
        'site_tagline',
        'site_logo',
        'favicon',
        'footer_disclaimer',

        'home_hero_badge',
        'home_hero_title',
        'home_hero_highlight',
        'home_hero_description',
        'home_primary_button_text',
        'home_secondary_button_text',
        'home_third_button_text',
        'home_hero_image',
        'home_how_image',
        'home_lab_image',
        'home_how_title',
        'home_how_description',
        'home_lab_title',
        'home_lab_description',
    ];

    public static function current(): self
    {
        return self::query()->firstOrCreate(
            ['id' => 1],
            [
                'site_name' => 'COAVerify™',
                'site_tagline' => 'Batch Purity Verification',
                'footer_disclaimer' => 'COAVerify™ facilitates independent third-party analytical verification through partner laboratory networks.',
            ]
        );
    }
}