

<?php $__env->startSection('title', 'COA Reports - COAVerify™'); ?>
<?php $__env->startSection('page_title', 'COA Reports'); ?>
<?php $__env->startSection('page_subtitle', 'Create and manage public batch verification records.'); ?>

<?php $__env->startSection('page_actions'); ?>
    <a href="<?php echo e(route('admin.coa-reports.create')); ?>" class="btn btn-primary">Add COA Report</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="panel" style="margin-bottom:18px;">
    <form method="GET" action="<?php echo e(route('admin.coa-reports.index')); ?>">
        <div class="form-grid">
            <div class="form-group">
                <label>Search</label>
                <input
                    type="text"
                    name="q"
                    value="<?php echo e(request('q')); ?>"
                    placeholder="Batch, product, company..."
                >
            </div>

            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="">All Status</option>
                    <option value="verified" <?php echo e(request('status') === 'verified' ? 'selected' : ''); ?>>Verified</option>
                    <option value="pending" <?php echo e(request('status') === 'pending' ? 'selected' : ''); ?>>Pending</option>
                    <option value="revoked" <?php echo e(request('status') === 'revoked' ? 'selected' : ''); ?>>Revoked</option>
                </select>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="<?php echo e(route('admin.coa-reports.index')); ?>" class="btn btn-outline">Reset</a>
        </div>
    </form>
</div>

<div class="panel">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Batch</th>
                    <th>Product</th>
                    <th>Purity</th>
                    <th>Company</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th style="width:240px;">Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <strong style="color:#fff;"><?php echo e($report->batch_number); ?></strong>
                        </td>

                        <td>
                            <strong style="color:#fff;"><?php echo e($report->product_name); ?></strong><br>
                            <span style="color:#b9b9b9;"><?php echo e($report->strength ?: '-'); ?></span>
                        </td>

                        <td>
                            <?php if(!is_null($report->purity_percent)): ?>
                                <?php echo e(number_format((float) $report->purity_percent, 2)); ?>%
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>

                        <td><?php echo e($report->client_company_name); ?></td>

                        <td>
                            <?php echo e($report->verification_date ? $report->verification_date->format('d M Y') : '-'); ?>

                        </td>

                        <td>
                            <?php if($report->status === 'verified'): ?>
                                <span class="status-active">Verified</span>
                            <?php elseif($report->status === 'pending'): ?>
                                <span style="color:#fde68a;font-weight:900;">Pending</span>
                            <?php else: ?>
                                <span class="status-inactive">Revoked</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <div class="action-row">
                                <a
                                    href="<?php echo e(route('verify.index')); ?>"
                                    target="_blank"
                                    class="btn btn-outline"
                                >
                                    Verify
                                </a>

                                <?php if($report->status === 'verified'): ?>
                                    <a
                                        href="<?php echo e(route('verify.report.download', $report)); ?>"
                                        target="_blank"
                                        class="btn btn-outline"
                                    >
                                        PDF
                                    </a>
                                <?php endif; ?>

                                <a href="<?php echo e(route('admin.coa-reports.edit', $report)); ?>" class="btn btn-primary">
                                    Edit
                                </a>

                                <form method="POST" action="<?php echo e(route('admin.coa-reports.destroy', $report)); ?>" onsubmit="return confirm('Delete this COA report?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7">No COA reports found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div style="margin-top:18px;">
        <?php echo e($reports->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MSTS\pharma-company\resources\views/admin/coa-reports/index.blade.php ENDPATH**/ ?>