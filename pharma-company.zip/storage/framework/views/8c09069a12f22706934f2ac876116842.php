

<?php $__env->startSection('title', 'Add COA Report - COAVerify™'); ?>
<?php $__env->startSection('page_title', 'Add COA Report'); ?>
<?php $__env->startSection('page_subtitle', 'Create a new public batch verification record.'); ?>

<?php $__env->startSection('page_actions'); ?>
    <a href="<?php echo e(route('admin.coa-reports.index')); ?>" class="btn btn-outline">Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="panel">
    <form method="POST" action="<?php echo e(route('admin.coa-reports.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-grid">
            <div class="form-group">
                <label>Batch Number *</label>
                <input type="text" name="batch_number" value="<?php echo e(old('batch_number')); ?>" placeholder="EP0861" required>
            </div>

            <div class="form-group">
                <label>Status *</label>
                <select name="status" required>
                    <option value="verified" <?php echo e(old('status', 'verified') === 'verified' ? 'selected' : ''); ?>>Verified</option>
                    <option value="pending" <?php echo e(old('status') === 'pending' ? 'selected' : ''); ?>>Pending</option>
                    <option value="revoked" <?php echo e(old('status') === 'revoked' ? 'selected' : ''); ?>>Revoked</option>
                </select>
            </div>

            <div class="form-group">
                <label>Product Name *</label>
                <input type="text" name="product_name" value="<?php echo e(old('product_name')); ?>" placeholder="RETATRUTIDE" required>
            </div>

            <div class="form-group">
                <label>Strength</label>
                <input type="text" name="strength" value="<?php echo e(old('strength')); ?>" placeholder="30mg">
            </div>

            <div class="form-group">
                <label>Purity %</label>
                <input type="number" step="0.01" min="0" max="100" name="purity_percent" value="<?php echo e(old('purity_percent')); ?>" placeholder="99.70">
            </div>

            <div class="form-group">
                <label>Verification Date</label>
                <input type="date" name="verification_date" value="<?php echo e(old('verification_date', now()->toDateString())); ?>">
            </div>

            <div class="form-group">
                <label>Client / Company Name *</label>
                <input type="text" name="client_company_name" value="<?php echo e(old('client_company_name')); ?>" placeholder="Elite Pharm USA" required>
            </div>

            <div class="form-group">
                <label>Brand Name on Report</label>
                <input type="text" name="report_brand_name" value="<?php echo e(old('report_brand_name')); ?>" placeholder="ELITE PHARM USA">
            </div>

            <div class="form-group">
                <label>Expiry Label</label>
                <input type="text" name="expiry_label" value="<?php echo e(old('expiry_label')); ?>" placeholder="4/28">
            </div>

            <div class="form-group">
                <label>Usage Text</label>
                <input type="text" name="usage_text" value="<?php echo e(old('usage_text', 'For Research Use Only')); ?>" placeholder="For Research Use Only">
            </div>

            <div class="form-group full">
                <label>Blend Title</label>
                <input type="text" name="blend_title" value="<?php echo e(old('blend_title')); ?>" placeholder="Proprietary Peptide Blend / Verified Peptide Sample">
            </div>

            <div class="form-group full">
                <label>Blend Breakdown</label>
                <input type="text" name="blend_breakdown" value="<?php echo e(old('blend_breakdown')); ?>" placeholder="80mg Total (10+10+50+10) / Purity Verified: 99.70%">
            </div>

            <div class="form-group">
                <label>Optional Uploaded PDF</label>
                <input type="file" name="report_pdf" accept=".pdf">
                <span class="help">Optional PDF upload. System generated report will still work.</span>
            </div>

            <div class="form-group">
                <label>Optional Label Image</label>
                <input type="file" name="sample_label_image" accept=".jpg,.jpeg,.png,.webp">
                <span class="help">Optional label image if you want to store original label.</span>
            </div>

            <div class="form-group full">
                <label>Internal Notes</label>
                <textarea name="notes" placeholder="Internal notes only"><?php echo e(old('notes')); ?></textarea>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Save COA Report</button>
            <a href="<?php echo e(route('admin.coa-reports.index')); ?>" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MSTS\pharma-company\resources\views/admin/coa-reports/create.blade.php ENDPATH**/ ?>