

<?php $__env->startSection('title', 'Sample Submissions - COAVerify™'); ?>
<?php $__env->startSection('page_title', 'Sample Submissions'); ?>
<?php $__env->startSection('page_subtitle', 'Review submitted sample details, uploaded label images, COA files, and verification status.'); ?>

<?php $__env->startSection('content'); ?>

<div class="panel" style="margin-bottom:18px;">
    <form method="GET" action="<?php echo e(route('admin.sample-submissions.index')); ?>">
        <div class="form-grid">
            <div class="form-group">
                <label>Search</label>
                <input
                    type="text"
                    name="q"
                    value="<?php echo e(request('q')); ?>"
                    placeholder="Company, product, batch, email..."
                >
            </div>

            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="">All Status</option>
                    <option value="new" <?php echo e(request('status') === 'new' ? 'selected' : ''); ?>>New</option>
                    <option value="under_review" <?php echo e(request('status') === 'under_review' ? 'selected' : ''); ?>>Under Review</option>
                    <option value="verified" <?php echo e(request('status') === 'verified' ? 'selected' : ''); ?>>Verified</option>
                    <option value="rejected" <?php echo e(request('status') === 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                </select>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="<?php echo e(route('admin.sample-submissions.index')); ?>" class="btn btn-outline">Reset</a>
        </div>
    </form>
</div>

<div class="panel">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Company</th>
                    <th>Product</th>
                    <th>Batch</th>
                    <th>Contact</th>
                    <th>Files</th>
                    <th>Status</th>
                    <th style="width:220px;">Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <?php echo e($submission->created_at ? $submission->created_at->format('d M Y') : '-'); ?><br>
                            <span style="color:#b9b9b9;">
                                <?php echo e($submission->created_at ? $submission->created_at->format('h:i A') : ''); ?>

                            </span>
                        </td>

                        <td>
                            <strong style="color:#fff;"><?php echo e($submission->company_name); ?></strong><br>
                            <span style="color:#b9b9b9;"><?php echo e($submission->contact_name ?: '-'); ?></span>
                        </td>

                        <td>
                            <strong style="color:#fff;"><?php echo e($submission->product_name); ?></strong><br>
                            <span style="color:#b9b9b9;"><?php echo e($submission->strength ?: '-'); ?></span>
                        </td>

                        <td><?php echo e($submission->batch_number ?: '-'); ?></td>

                        <td>
                            <?php echo e($submission->email); ?><br>
                            <span style="color:#b9b9b9;"><?php echo e($submission->phone ?: '-'); ?></span>
                        </td>

                        <td>
                            <?php if($submission->sample_label_image): ?>
                                <a href="<?php echo e(asset('storage/' . $submission->sample_label_image)); ?>" target="_blank" class="btn btn-outline">
                                    Label
                                </a>
                            <?php endif; ?>

                            <?php if($submission->coa_file): ?>
                                <a href="<?php echo e(asset('storage/' . $submission->coa_file)); ?>" target="_blank" class="btn btn-outline">
                                    File
                                </a>
                            <?php endif; ?>

                            <?php if(!$submission->sample_label_image && !$submission->coa_file): ?>
                                -
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if($submission->status === 'new'): ?>
                                <span style="color:#93c5fd;font-weight:900;">New</span>
                            <?php elseif($submission->status === 'under_review'): ?>
                                <span style="color:#fde68a;font-weight:900;">Under Review</span>
                            <?php elseif($submission->status === 'verified'): ?>
                                <span class="status-active">Verified</span>
                            <?php else: ?>
                                <span class="status-inactive">Rejected</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <div class="action-row">
                                <a href="<?php echo e(route('admin.sample-submissions.show', $submission)); ?>" class="btn btn-outline">
                                    View
                                </a>

                                <a href="<?php echo e(route('admin.sample-submissions.edit', $submission)); ?>" class="btn btn-primary">
                                    Edit
                                </a>

                                <form method="POST" action="<?php echo e(route('admin.sample-submissions.destroy', $submission)); ?>" onsubmit="return confirm('Delete this sample submission?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8">No sample submissions found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div style="margin-top:18px;">
        <?php echo e($submissions->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MSTS\pharma-company\resources\views/admin/sample-submissions/index.blade.php ENDPATH**/ ?>