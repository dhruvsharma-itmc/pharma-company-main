

<?php $__env->startSection('title', 'Service Items - COAVerify™'); ?>
<?php $__env->startSection('page_title', 'Service Items'); ?>
<?php $__env->startSection('page_subtitle', 'Manage sample review options displayed inside each service category.'); ?>

<?php $__env->startSection('page_actions'); ?>
    <a href="<?php echo e(route('admin.service-items.create')); ?>" class="btn btn-primary">Add Service Item</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="panel">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Order</th>
                    <th>Item</th>
                    <th>Category</th>
                    <th>Price / Label</th>
                    <th>Status</th>
                    <th style="width:170px;">Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($item->sort_order); ?></td>

                        <td>
                            <strong style="color:#fff;"><?php echo e($item->title); ?></strong><br>
                            <span style="color:#b9b9b9;"><?php echo e($item->short_description); ?></span>
                        </td>

                        <td><?php echo e($item->category?->title ?? '-'); ?></td>
                        <td><?php echo e($item->price_label ?? 'Request Review'); ?></td>

                        <td>
                            <?php if($item->is_active): ?>
                                <span class="status-active">Active</span>
                            <?php else: ?>
                                <span class="status-inactive">Inactive</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <div class="action-row">
                                <a href="<?php echo e(route('admin.service-items.edit', $item)); ?>" class="btn btn-primary">
                                    Edit
                                </a>

                                <form method="POST" action="<?php echo e(route('admin.service-items.destroy', $item)); ?>" onsubmit="return confirm('Delete this service item?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">No service items found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div style="margin-top:18px;">
        <?php echo e($items->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MSTS\pharma-company\resources\views/admin/services/items/index.blade.php ENDPATH**/ ?>